Run_PyInstaller
David Ray

V0.01.00 - 10-23-2016
***	Initial Release

V0.01.01 - 10-24-2016
***	Added the ability to use PIP from inside Run_PyInstaller to download and install the PyInstaller package and upgrades as needed.
***	Added the function to copy files names 'readme.txt' or 'changelog.txt' to the compiled software after the compiling is complete.

V0.01.02 - 20-24-2016
***	Added '.lower()' to raw_input checks.
***	Added the function to saw that your application name and your '.py' names are the same.  This way you don't have to type it in twice.
***	Added justification commands to lines printed to the console.

V0.01.03 - 11-11-2016
***	Rewrote for compatiblity with Python 3.5

V0.01.04 - 11-16-2016
***	Updated contact information.

V0.01.05 - 11-16-2016
***	Correct some syntax errors.